google.maps.__gjsload__('infowindow', function(_) {
    var mO = function(a) {
            return !!a.infoWindow.get("logAsInternal")
        },
        oKa = function(a, b) {
            if (a.Eg.size === 1) {
                const c = Array.from(a.Eg.values())[0];
                c.du !== b.du && (c.set("map", null), a.Eg.delete(c))
            }
            a.Eg.add(b)
        },
        qKa = function(a, b) {
            var c = a.__gm;
            a = c.get("panes");
            c = c.get("innerContainer");
            b = {
                pl: a,
                vj: _.fB.vj(),
                Nv: c,
                shouldFocus: b
            };
            return new pKa(b)
        },
        nO = function(a, b) {
            a.gh.style.visibility = b ? "" : "hidden";
            b && a.shouldFocus && (a.focus(), a.shouldFocus = !1);
            b ? rKa(a) : a.Pg = !1
        },
        sKa = function(a) {
            a.Hi.setAttribute("aria-labelledby", a.Kg.id)
        },
        tKa = function(a) {
            const b = !!a.get("open");
            var c = a.get("content");
            c = b ? c : null;
            if (c == a.Ig) nO(a, b && a.get("position"));
            else {
                if (a.Ig) {
                    const d = a.Ig.parentNode;
                    d == a.Eg && d.removeChild(a.Ig)
                }
                c && (a.Ng = !1, a.Eg.appendChild(c));
                nO(a, b && a.get("position"));
                a.Ig = c;
                oO(a)
            }
        },
        pO = function(a) {
            var b = !!a.get("open"),
                c = a.get("headerContent");
            const d = !!a.get("ariaLabel"),
                e = !a.get("headerDisabled");
            b = b ? c : null;
            a.Hi.style.paddingTop = e ? "0" : "12px";
            b === a.Jg ? a.Gg.style.display = e ? "" : "none" : (a.Jg && (c = a.Jg.parentNode, c === a.Kg && c.removeChild(a.Jg)),
                b && (a.Ng = !1, a.Kg.appendChild(b), e && !d && sKa(a)), a.Gg.style.display = e ? "" : "none", a.Jg = b, oO(a))
        },
        oO = function(a) {
            var b = a.getSize();
            if (b) {
                var c = b.Nl;
                b = b.minWidth;
                a.Hi.style.maxWidth = _.Eu(c.width);
                a.Hi.style.maxHeight = _.Eu(c.height);
                a.Hi.style.minWidth = _.Eu(b);
                a.Eg.style.maxHeight = _.Wn.Eg ? _.Eu(c.height - 18) : _.Eu(c.height - 36);
                qO(a);
                a.Mg.start()
            }
        },
        uKa = function(a) {
            const b = a.get("pixelOffset") || new _.Yl(0, 0);
            var c = new _.Yl(a.Hi.offsetWidth, a.Hi.offsetHeight);
            a = -b.height + c.height + 11 + 60;
            let d = b.height + 60;
            const e = -b.width + c.width / 2 + 60;
            c = b.width + c.width / 2 + 60;
            b.height < 0 && (d -= b.height);
            return {
                top: a,
                bottom: d,
                left: e,
                right: c
            }
        },
        rKa = function(a) {
            !a.Pg && a.get("open") && a.get("visible") && a.get("position") && (_.Rk(a, "visible"), a.Pg = !0)
        },
        qO = function(a) {
            var b = a.get("position");
            if (b && a.get("pixelOffset")) {
                var c = uKa(a);
                const d = b.x - c.left,
                    e = b.y - c.top,
                    f = b.x + c.right;
                c = b.y + c.bottom;
                _.av(a.anchor, b);
                b = a.get("zIndex");
                _.cv(a.gh, _.qj(b) ? b : e + 60);
                a.set("pixelBounds", _.bn(d, e, f, c))
            }
        },
        wKa = function(a, b, c) {
            return b instanceof _.al ? new vKa(a,
                b, c) : new vKa(a, b)
        },
        yKa = function(a) {
            a.Eg && a.ii.push(_.Ok(a.Eg, "pixelposition_changed", () => {
                xKa(a)
            }))
        },
        xKa = function(a) {
            const b = a.model.get("pixelPosition") || a.Eg && a.Eg.get("pixelPosition");
            a.Ig.set("position", b)
        },
        AKa = function(a) {
            a = a.__gm;
            a.get("IW_AUTO_CLOSER") || a.set("IW_AUTO_CLOSER", new zKa);
            return a.get("IW_AUTO_CLOSER")
        },
        zKa = class {
            constructor() {
                this.Eg = new Set
            }
        };
    var pKa = class extends _.Vk {
        constructor(a) {
            super();
            this.Ig = this.Jg = this.Og = null;
            this.Pg = this.Ng = !1;
            this.Nv = a.Nv;
            this.shouldFocus = a.shouldFocus;
            this.gh = document.createElement("div");
            this.gh.style.cursor = "default";
            this.gh.style.position = "absolute";
            this.gh.style.left = this.gh.style.top = "0";
            a.pl.floatPane.appendChild(this.gh);
            this.anchor = _.bv("div", this.gh);
            this.Lg = _.bv("div", this.anchor);
            this.Hi = _.bv("div", this.Lg);
            this.Hi.setAttribute("role", "dialog");
            this.Hi.tabIndex = -1;
            this.Gg = _.bv("div", this.Hi);
            this.Kg =
                _.bv("div", this.Gg);
            this.Sg = _.bv("div", this.Lg);
            this.Eg = _.bv("div", this.Hi);
            _.hBa(this.gh);
            _.Wu(this.Hi, "gm-style-iw");
            _.Wu(this.anchor, "gm-style-iw-a");
            _.Wu(this.Lg, "gm-style-iw-t");
            _.Wu(this.Sg, "gm-style-iw-tc");
            _.Wu(this.Hi, "gm-style-iw-c");
            _.Wu(this.Gg, "gm-style-iw-chr");
            _.Wu(this.Kg, "gm-style-iw-ch");
            _.Wu(this.Eg, "gm-style-iw-d");
            this.Kg.setAttribute("id", _.Cp());
            _.Wn.Eg && !_.Wn.Lg && (this.Hi.style.paddingInlineEnd = "0", this.Hi.style.paddingBottom = "0", this.Eg.style.overflow = "scroll");
            nO(this, !1);
            _.Kk(this.gh, "mousedown", _.Bk);
            _.Kk(this.gh, "mouseup", _.Bk);
            _.Kk(this.gh, "mousemove", _.Bk);
            _.Kk(this.gh, "pointerdown", _.Bk);
            _.Kk(this.gh, "pointerup", _.Bk);
            _.Kk(this.gh, "pointermove", _.Bk);
            _.Kk(this.gh, "dblclick", _.Bk);
            _.Kk(this.gh, "click", _.Bk);
            _.Kk(this.gh, "touchstart", _.Bk);
            _.Kk(this.gh, "touchend", _.Bk);
            _.Kk(this.gh, "touchmove", _.Bk);
            _.Hu(this.gh, "contextmenu", this, this.Rg);
            _.Hu(this.gh, "wheel", this, _.Bk);
            _.Hu(this.gh, "mousewheel", this, _.yk);
            _.Hu(this.gh, "MozMousePixelScroll", this, _.yk);
            this.Fg =
                new _.HA({
                    Rp: new _.Wl(12, 12),
                    cr: new _.Yl(24, 24),
                    offset: new _.Wl(-6, -6),
                    wz: !0,
                    ownerElement: this.Gg
                });
            this.Gg.appendChild(this.Fg.element);
            _.Kk(this.Fg.element, "click", b => {
                _.Bk(b);
                _.Rk(this, "closeclick");
                this.set("open", !1)
            });
            this.Mg = new _.En(() => {
                !this.Ng && this.get("content") && this.get("visible") && (_.Rk(this, "domready"), this.Ng = !0)
            }, 0);
            this.Qg = _.Kk(this.gh, "keydown", b => {
                b.key !== "Escape" && b.key !== "Esc" || !this.Hi.contains(document.activeElement) || (b.stopPropagation(), _.Rk(this, "closeclick"), this.set("open", !1))
            })
        }
        ariaLabel_changed() {
            const a = this.get("ariaLabel");
            a ? this.Hi.setAttribute("aria-label", a) : (this.Hi.removeAttribute("aria-label"), this.get("headerDisabled") || sKa(this))
        }
        open_changed() {
            tKa(this);
            pO(this)
        }
        headerContent_changed() {
            pO(this)
        }
        headerDisabled_changed() {
            pO(this)
        }
        content_changed() {
            tKa(this)
        }
        pendingFocus_changed() {
            this.get("pendingFocus") && (this.get("open") && this.get("visible") && this.get("position") ? _.ho(this.Hi, !0) : console.warn("Setting focus on InfoWindow was ignored. This is most likely due to InfoWindow not being visible yet."),
                this.set("pendingFocus", !1))
        }
        dispose() {
            setTimeout(() => {
                document.activeElement && document.activeElement !== document.body || (this.Og && this.Og !== document.body ? _.ho(this.Og, !0) || _.ho(this.Nv, !0) : _.ho(this.Nv, !0))
            });
            this.Qg && _.Fk(this.Qg);
            this.gh.parentNode.removeChild(this.gh);
            this.Mg.stop();
            this.Mg.dispose()
        }
        getSize() {
            var a = this.get("layoutPixelBounds"),
                b = this.get("pixelOffset");
            const c = this.get("maxWidth") || 648,
                d = this.get("minWidth") || 0;
            if (!b) return null;
            a ? (b = a.maxY - a.minY - (11 + -b.height), a = a.maxX - a.minX -
                6, a >= 240 && (a -= 120), b >= 240 && (b -= 120)) : (a = 648, b = 654);
            a = Math.min(a, c);
            a = Math.max(d, a);
            a = Math.max(0, a);
            b = Math.max(0, b);
            return {
                Nl: new _.Yl(a, b),
                minWidth: d
            }
        }
        pixelOffset_changed() {
            const a = this.get("pixelOffset") || new _.Yl(0, 0);
            this.Lg.style.right = _.Eu(-a.width);
            this.Lg.style.bottom = _.Eu(-a.height + 11);
            oO(this)
        }
        layoutPixelBounds_changed() {
            oO(this)
        }
        position_changed() {
            this.get("position") ? (qO(this), nO(this, !!this.get("open"))) : nO(this, !1)
        }
        zIndex_changed() {
            qO(this)
        }
        visible_changed() {
            this.gh.style.display = this.get("visible") ?
                "" : "none";
            this.Mg.start();
            if (this.get("visible")) {
                const a = this.Fg.element.style.display;
                this.Fg.element.style.display = "none";
                this.Fg.element.getBoundingClientRect();
                this.Fg.element.style.display = a;
                rKa(this)
            } else this.Pg = !1
        }
        Rg(a) {
            let b = !1;
            const c = this.get("content");
            let d = a.target;
            for (; !b && d;) b = d == c, d = d.parentNode;
            b ? _.yk(a) : _.Ak(a)
        }
        focus() {
            this.Og = document.activeElement;
            let a;
            _.Wn.Mg && (a = this.Eg.getBoundingClientRect());
            if (this.get("disableAutoPan")) _.ho(this.Hi, !0);
            else {
                var b = _.hv(this.Eg);
                if (b.length) {
                    b =
                        b[0];
                    a = a || this.Eg.getBoundingClientRect();
                    var c = b.getBoundingClientRect();
                    _.ho(c.bottom <= a.bottom && c.right <= a.right ? b : this.Hi, !0)
                } else _.ho(this.Fg.element, !0)
            }
        }
    };
    var vKa = class {
        constructor(a, b, c) {
            this.model = a;
            this.isOpen = !0;
            this.Eg = this.Gg = this.kh = null;
            this.ii = [];
            var d = a.get("shouldFocus");
            this.Ig = qKa(b, d);
            const e = b.__gm;
            (d = b instanceof _.al) && c ? c.then(h => {
                this.isOpen && (this.kh = h, this.Eg = new _.MK(k => {
                    this.Gg = new _.BA(b, h, k, () => {});
                    h.Bi(this.Gg);
                    return this.Gg
                }), this.Eg.bindTo("latLngPosition", a, "position"), yKa(this))
            }) : (this.Eg = new _.MK, this.Eg.bindTo("latLngPosition", a, "position"), this.Eg.bindTo("center", e, "projectionCenterQ"), this.Eg.bindTo("zoom", e), this.Eg.bindTo("offset",
                e), this.Eg.bindTo("projection", b), this.Eg.bindTo("focus", b, "position"), yKa(this));
            this.Jg = d ? mO(a) ? "Ia" : "Id" : null;
            this.Kg = d ? mO(a) ? 148284 : 148285 : null;
            const f = new _.NK(["scale"], "visible", h => h == null || h >= .3);
            this.Eg && f.bindTo("scale", this.Eg);
            const g = this.Ig;
            g.set("logAsInternal", mO(a));
            g.bindTo("ariaLabel", a);
            g.bindTo("zIndex", a);
            g.bindTo("layoutPixelBounds", e, "pixelBounds");
            g.bindTo("disableAutoPan", a);
            g.bindTo("pendingFocus", a);
            g.bindTo("maxWidth", a);
            g.bindTo("minWidth", a);
            g.bindTo("content", a);
            g.bindTo("headerContent",
                a);
            g.bindTo("headerDisabled", a);
            g.bindTo("pixelOffset", a);
            g.bindTo("visible", f);
            this.Fg = new _.En(() => {
                if (b instanceof _.al)
                    if (this.kh) {
                        var h = a.get("position");
                        h && _.qfa(b, this.kh, new _.yl(h), uKa(g))
                    } else c.then(() => {
                        this.Fg.start()
                    });
                else(h = g.get("pixelBounds")) ? _.Rk(e, "pantobounds", h) : this.Fg.start()
            }, 150);
            if (d) {
                let h = null;
                this.ii.push(_.Ok(a, "position_changed", () => {
                    const k = a.get("position");
                    !k || a.get("disableAutoPan") || k.equals(h) || (this.Fg.start(), h = k)
                }))
            } else a.get("disableAutoPan") || this.Fg.start();
            g.set("open", !0);
            this.ii.push(_.Dk(g, "domready", () => {
                a.trigger("domready")
            }));
            this.ii.push(_.Dk(g, "visible", () => {
                a.trigger("visible")
            }));
            this.ii.push(_.Dk(g, "closeclick", () => {
                a.close();
                a.trigger("closeclick")
            }));
            this.ii.push(_.Ok(a, "pixelposition_changed", () => {
                xKa(this)
            }));
            this.Jg && _.Pl(b, this.Jg);
            this.Kg && _.Nl(b, this.Kg)
        }
        close() {
            if (this.isOpen) {
                this.isOpen = !1;
                this.model.trigger("close");
                for (var a of this.ii) _.Fk(a);
                this.ii.length = 0;
                this.Fg.stop();
                this.Fg.dispose();
                this.kh && this.Gg && this.kh.rm(this.Gg);
                a = this.Ig;
                a.unbindAll();
                a.set("open", !1);
                a.dispose();
                this.Eg && this.Eg.unbindAll()
            }
        }
    };
    _.vk("infowindow", {
        qE: function(a) {
            let b = null;
            _.Ok(a, "map_changed", function d() {
                const e = a.get("map");
                b && (b.CA.Eg.delete(a), b.fI.close(), b = null);
                if (e) {
                    const f = e.__gm;
                    f.get("panes") ? f.get("innerContainer") ? (b = {
                        fI: wKa(a, e, e instanceof _.al ? f.Fg.then(({
                            kh: g
                        }) => g) : void 0),
                        CA: AKa(e)
                    }, oKa(b.CA, a)) : _.Nk(f, "innercontainer_changed", d) : _.Nk(f, "panes_changed", d)
                }
            })
        }
    });
});